from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Sum, Count
from django.utils import timezone
from django.db import transaction
from django.http import JsonResponse
from datetime import timedelta
from decimal import Decimal
import json

from .models import (
    Producto, Venta, Cliente, Proveedor, DetalleVenta,
    CategoriaProducto, Abono, OrdenPedido, DetalleOrdenPedido,
    RecepcionProducto, DetalleRecepcion
)


# -----------------------------
# ROLES
# -----------------------------
def es_admin(user):
    return user.is_superuser


def es_vendedor(user):
    return not user.is_superuser


# -----------------------------
# LOGIN
# -----------------------------
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)

            # Redirección según rol
            if user.is_superuser:
                return redirect('home')
            else:
                return redirect('ventas')

        messages.error(request, "Credenciales incorrectas.")
        return redirect('login')

    return render(request, "login.html")


# -----------------------------
# LOGOUT
# -----------------------------
@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


# -----------------------------
# HOME – SOLO ADMIN
# -----------------------------
@login_required
@user_passes_test(es_admin, login_url='/ventas/')
def home(request):
    # Estadísticas generales
    total_productos = Producto.objects.count()
    total_ventas = Venta.objects.count()
    productos_bajo_stock = Producto.objects.filter(stock__lt=10).count()
    total_clientes = Cliente.objects.count()
    total_proveedores = Proveedor.objects.count()
    
    # Ventas del mes actual
    hoy = timezone.now()
    inicio_mes = hoy.replace(day=1)
    ventas_mes = Venta.objects.filter(fecha__gte=inicio_mes).aggregate(
        total=Sum('total')
    )['total'] or 0
    
    context = {
        'total_productos': total_productos,
        'total_ventas': total_ventas,
        'productos_bajo_stock': productos_bajo_stock,
        'total_clientes': total_clientes,
        'total_proveedores': total_proveedores,
        'ventas_mes': ventas_mes,
    }
    return render(request, "home.html", context)


# -----------------------------
# PRODUCTOS – ADMIN Y VENDEDOR
# -----------------------------
@login_required
def productos(request):
    query = request.GET.get('q', '')
    lista = Producto.objects.all()
    
    if query:
        lista = lista.filter(nombre__icontains=query) | lista.filter(codigo__icontains=query)
    
    return render(request, "productos.html", {"productos": lista, "query": query})


# -----------------------------
# INVENTARIO – SOLO ADMIN
# -----------------------------
@login_required
@user_passes_test(es_admin, login_url='/')
def inventario(request):
    lista = Producto.objects.all().order_by('stock')
    return render(request, "inventario.html", {"productos": lista})


# -----------------------------
# VENTAS – ADMIN Y VENDEDOR
# -----------------------------
@login_required
def ventas(request):
    # Si es vendedor, solo ve sus propias ventas
    if request.user.is_superuser:
        lista = Venta.objects.all().order_by('-fecha')[:20]
    else:
        lista = Venta.objects.filter(vendedor=request.user).order_by('-fecha')[:20]
    
    return render(request, "ventas.html", {"ventas": lista})


# -----------------------------
# REGISTRAR VENTA
# -----------------------------
@login_required
def registrar_venta(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            
            with transaction.atomic():
                # Generar número de boleta
                ultima_venta = Venta.objects.all().order_by('-id').first()
                if ultima_venta and ultima_venta.numero_boleta:
                    ultimo_numero = int(ultima_venta.numero_boleta)
                    nuevo_numero = str(ultimo_numero + 1).zfill(10)
                else:
                    nuevo_numero = "0000000001"
                
                # Obtener cliente si es crédito
                cliente = None
                if data['tipo_pago'] == 'credito':
                    cliente = Cliente.objects.get(id=data['cliente_id'])
                
                # Crear venta
                venta = Venta.objects.create(
                    numero_boleta=nuevo_numero,
                    cliente=cliente,
                    vendedor=request.user,
                    tipo_pago=data['tipo_pago'],
                    total=Decimal(data['total'])
                )
                
                # Crear detalles y actualizar stock
                for item in data['items']:
                    producto = Producto.objects.get(id=item['producto_id'])
                    
                    # Verificar stock
                    if producto.stock < item['cantidad']:
                        raise Exception(f"Stock insuficiente para {producto.nombre}")
                    
                    # Crear detalle
                    DetalleVenta.objects.create(
                        venta=venta,
                        producto=producto,
                        cantidad=item['cantidad'],
                        precio_unitario=producto.precio,
                        subtotal=Decimal(item['cantidad']) * producto.precio
                    )
                    
                    # Actualizar stock
                    producto.stock -= item['cantidad']
                    producto.save()
                
                # Si es crédito, actualizar deuda
                if data['tipo_pago'] == 'credito' and cliente:
                    cliente.deuda_actual += Decimal(data['total'])
                    cliente.save()
                
                return JsonResponse({
                    'success': True,
                    'numero_boleta': nuevo_numero,
                    'message': f'Venta registrada exitosamente. Boleta N° {nuevo_numero}'
                })
                
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    
    # GET: Mostrar formulario
    productos = Producto.objects.filter(stock__gt=0).order_by('nombre')
    clientes = Cliente.objects.filter(estado='activo').order_by('nombre')
    
    return render(request, "registrar_venta.html", {
        'productos': productos,
        'clientes': clientes
    })


# -----------------------------
# CLIENTES – TODOS
# -----------------------------
@login_required
def clientes(request):
    lista = Cliente.objects.all().order_by('nombre')
    return render(request, "clientes.html", {"clientes": lista})


# -----------------------------
# DETALLE DE VENTA
# -----------------------------
@login_required
def detalle_venta(request, venta_id):
    venta = get_object_or_404(Venta, id=venta_id)
    
    # Si es vendedor, solo puede ver sus propias ventas
    if not request.user.is_superuser and venta.vendedor != request.user:
        messages.error(request, "No tienes permiso para ver esta venta")
        return redirect('ventas')
    
    detalles = venta.detalles.all()
    
    return render(request, "detalles_venta.html", {
        'venta': venta,
        'detalles': detalles
    })