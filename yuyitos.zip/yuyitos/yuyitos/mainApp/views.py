from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import timedelta

from .models import Producto, Venta, Cliente, Proveedor


# -----------------------------
# ROLES
# -----------------------------
def es_admin(user):
    return user.is_superuser


def es_vendedor(user):
    return not user.is_superuser


# -----------------------------
# LOGIN
# -----------------------------
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)

            # Redirección según rol
            if user.is_superuser:
                return redirect('home')
            else:
                return redirect('ventas')

        messages.error(request, "Credenciales incorrectas.")
        return redirect('login')

    return render(request, "login.html")


# -----------------------------
# LOGOUT
# -----------------------------
@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


# -----------------------------
# HOME – SOLO ADMIN
# -----------------------------
@login_required
@user_passes_test(es_admin, login_url='/ventas/')
def home(request):
    # Estadísticas generales
    total_productos = Producto.objects.count()
    total_ventas = Venta.objects.count()
    productos_bajo_stock = Producto.objects.filter(stock__lt=10).count()
    total_clientes = Cliente.objects.count()
    total_proveedores = Proveedor.objects.count()
    
    # Ventas del mes actual
    hoy = timezone.now()
    inicio_mes = hoy.replace(day=1)
    ventas_mes = Venta.objects.filter(fecha__gte=inicio_mes).aggregate(
        total=Sum('total')
    )['total'] or 0
    
    context = {
        'total_productos': total_productos,
        'total_ventas': total_ventas,
        'productos_bajo_stock': productos_bajo_stock,
        'total_clientes': total_clientes,
        'total_proveedores': total_proveedores,
        'ventas_mes': ventas_mes,
    }
    return render(request, "home.html", context)


# -----------------------------
# PRODUCTOS – ADMIN Y VENDEDOR
# -----------------------------
@login_required
def productos(request):
    query = request.GET.get('q', '')
    lista = Producto.objects.all()
    
    if query:
        lista = lista.filter(nombre__icontains=query) | lista.filter(codigo__icontains=query)
    
    return render(request, "productos.html", {"productos": lista, "query": query})


# -----------------------------
# INVENTARIO – SOLO ADMIN
# -----------------------------
@login_required
@user_passes_test(es_admin, login_url='/')
def inventario(request):
    lista = Producto.objects.all().order_by('stock')
    return render(request, "inventario.html", {"productos": lista})


# -----------------------------
# VENTAS – ADMIN Y VENDEDOR
# -----------------------------
@login_required
def ventas(request):
    # Si es vendedor, solo ve sus propias ventas
    if request.user.is_superuser:
        lista = Venta.objects.all().order_by('-fecha')[:20]
    else:
        lista = Venta.objects.filter(vendedor=request.user).order_by('-fecha')[:20]
    
    return render(request, "ventas.html", {"ventas": lista})


# -----------------------------
# CLIENTES – TODOS
# -----------------------------
@login_required
def clientes(request):
    lista = Cliente.objects.all().order_by('nombre')
    return render(request, "clientes.html", {"clientes": lista})