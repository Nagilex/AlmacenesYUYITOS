from django.core.management.base import BaseCommand
from django.contrib.auth.models import User

class Command(BaseCommand):
    help = 'Crea los usuarios por defecto del sistema'

    def handle(self, *args, **kwargs):
        # Crear usuario Admin (Juanita)
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin',
                email='admin@yuyitos.cl',
                password='admin123',
                first_name='Juanita',
                last_name='Administradora'
            )
            self.stdout.write(self.style.SUCCESS('Usuario ADMIN creado exitosamente'))
        else:
            self.stdout.write(self.style.WARNING('Usuario ADMIN ya existe'))

        # Crear usuario Vendedora
        if not User.objects.filter(username='vendedora').exists():
            User.objects.create_user(
                username='vendedora',
                email='vendedora@yuyitos.cl',
                password='vendedora123',
                first_name='Maria',
                last_name='Vendedora'
            )
            self.stdout.write(self.style.SUCCESS('Usuario VENDEDORA creado exitosamente'))
        else:
            self.stdout.write(self.style.WARNING('Usuario VENDEDORA ya existe'))

        self.stdout.write(self.style.SUCCESS('\nProceso completado'))
        self.stdout.write(self.style.SUCCESS('Credenciales:'))
        self.stdout.write('   Admin: admin / admin123')
        self.stdout.write('   Vendedora: vendedora / vendedora123')